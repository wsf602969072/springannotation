CREATE TRIGGER EB_JBPM_TASK_TRIGGER
  AFTER INSERT
  ON JBPM4_TASK
  FOR EACH ROW
  declare
a varchar2(200);
d number;
begin
select   substr(:new.execution_id_ ,1,instr(:new.execution_id_,'.')) into a from dual;
if a ='ailk.'
then
select e.execution_id into d from Eb_Order_Execution e where e.execution = :new.execution_id_;
update Eb_Order_Execution e11 set e11.is_now =0 where e11.execution_id =d;
update Eb_Order_Execution e11 set e11.is_now =1 where e11.execution = :new.execution_id_;
end if;
end;

/

