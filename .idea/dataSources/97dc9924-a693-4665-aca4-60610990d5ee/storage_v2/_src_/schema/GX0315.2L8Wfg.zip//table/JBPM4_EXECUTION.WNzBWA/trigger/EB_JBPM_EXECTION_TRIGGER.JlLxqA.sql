CREATE TRIGGER EB_JBPM_EXECTION_TRIGGER
  AFTER INSERT
  ON JBPM4_EXECUTION
  FOR EACH ROW
  declare
a varchar2(200);
b number;
c number;
d number;
begin
if :new.superexec_ is null
then update Eb_Order_Execution e11 set e11.execution =:new.id_ , e11.is_now =1 where e11.execution_id =:new.dbid_;
else
/*
如果是第一次进入子流程，这insert，第二次则update
*/
select max(order_num) into a from eb_order_execution  where execution_id=:new.superexec_;
select count(1) into b from eb_order_execution  where substr(execution,1,instr(execution,'.')) = substr(:new.id_,1,instr(:new.id_,'.')) and execution_id =:new.superexec_;
select SEQORDEREXEC.NEXTVAL into c from dual;
if b=0
then
update Eb_Order_Execution e11 set e11.is_now =0 where e11.execution_id =:new.superexec_;
insert into Eb_Order_Execution values(c,a,:new.superexec_,:new.id_,1);
else
update Eb_Order_Execution e11 set e11.is_now =0 where e11.execution_id =:new.superexec_;
update Eb_Order_Execution  set execution=:new.id_,IS_NOW =1
where substr(execution,1,instr(execution,'.')) = substr(:new.id_,1,instr(:new.id_,'.'))
     and execution_id =:new.superexec_;
end if;
end if;
end;

/

