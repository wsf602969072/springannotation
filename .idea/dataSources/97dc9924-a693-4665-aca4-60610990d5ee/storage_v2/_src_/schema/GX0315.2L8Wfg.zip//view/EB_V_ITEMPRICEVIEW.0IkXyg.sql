CREATE VIEW EB_V_ITEMPRICEVIEW AS
  select item_id,min(sku_price) as minSkuPrice,max(sku_price) as maxSkuPrice,min(market_price) as minMarketPrice,max(market_price) as maxMarketPrice from eb_sku
where show_status=0 and sku_type=1
group by item_id

/

